package ir.uniticket.offline

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
    private val navy = Color.rgb(20, 42, 75)
    private val blue = Color.rgb(43, 105, 176)
    private val pale = Color.rgb(241, 246, 252)
    private lateinit var db: DemoDb
    private var role = "student"
    private var username = "student"
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DemoDb(this)
        showLogin()
    }

    private fun base(title: String, subtitle: String? = null): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pale)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(navy)
        }
        header.addView(text("UniTicket", 25, Color.WHITE, true))
        header.addView(text(title, 18, Color.WHITE, true).apply { setPadding(0, dp(8), 0, 0) })
        if (subtitle != null) header.addView(text(subtitle, 13, Color.LTGRAY).apply { setPadding(0, dp(5), 0, 0) })
        root.addView(header, LinearLayout.LayoutParams(-1, -2))
        val scroller = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(14), 0, dp(24))
        }
        scroller.addView(content)
        root.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        currentContent = content
        return content
    }
    private lateinit var currentContent: LinearLayout

    private fun showLogin() {
        val c = base("سامانه مدیریت تیکت دانشگاه", "نسخه نمایشی کاملاً آفلاین • اطلاعات فقط روی همین گوشی ذخیره می‌شوند")
        c.addView(text("ورود آزمایشی", 20, navy, true))
        c.addView(text("برای نمایش به مسئولان، یکی از نقش‌های زیر را انتخاب کنید.", 14, Color.DKGRAY).padTop(8))
        addButton(c, "ورود به‌عنوان دانشجو  ·  student / 1234") {
            role = "student"; username = "student"; showDashboard()
        }
        addButton(c, "ورود به‌عنوان مسئول  ·  staff / 1234") {
            role = "staff"; username = "staff"; showDashboard()
        }
        addButton(c, "ورود به‌عنوان مدیر  ·  admin / 1234") {
            role = "admin"; username = "admin"; showDashboard()
        }
        c.addView(text("حساب‌ها صرفاً نمایشی هستند و برای نسخه عملیاتی باید احراز هویت امن طراحی شود.", 12, Color.GRAY).padTop(16))
    }

    private fun showDashboard() {
        val roleName = when(role) { "student" -> "پنل دانشجو"; "staff" -> "پنل مسئول"; else -> "پنل مدیر" }
        val c = base(roleName, "کاربر: $username  •  حالت آفلاین")
        val tickets = db.tickets()
        val open = tickets.count { it.status == "در انتظار" }
        val done = tickets.count { it.status == "پاسخ داده شد" }
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stats.addView(statCard("کل تیکت‌ها", tickets.size.toString()), LinearLayout.LayoutParams(0, dp(90), 1f))
        stats.addView(statCard("در انتظار", open.toString()), LinearLayout.LayoutParams(0, dp(90), 1f))
        stats.addView(statCard("پاسخ داده‌شده", done.toString()), LinearLayout.LayoutParams(0, dp(90), 1f))
        c.addView(stats)
        if (role == "student") addButton(c, "＋ ثبت تیکت جدید") { newTicket() }
        if (role == "admin") {
            addButton(c, "مدیریت کاربران") { showUsers() }
            addButton(c, "گزارش سامانه") {
                AlertDialog.Builder(this).setTitle("گزارش آفلاین")
                    .setMessage("کاربران نمونه: 3\nتعداد تیکت‌ها: ${tickets.size}\nتیکت‌های در انتظار: $open")
                    .setPositiveButton("بستن", null).show()
            }
        }
        if (role == "staff") addButton(c, "نمایش تیکت‌های نیازمند پاسخ") { showTickets(true) }
        addButton(c, "مشاهده تیکت‌ها") { showTickets(false) }
        addButton(c, "اطلاعیه‌ها") { showAnnouncements() }
        addButton(c, "خروج از حساب") { showLogin() }
        c.addView(text("تیکت‌های اخیر", 18, navy, true).padTop(18))
        tickets.take(3).forEach { c.addView(ticketCard(it) { openTicket(it) }) }
    }

    private fun newTicket() {
        val c = base("ثبت تیکت", "ایجاد تیکت آزمایشی بدون اینترنت")
        val title = EditText(this).apply { hint = "عنوان تیکت"; textSize = 15f }
        val desc = EditText(this).apply { hint = "شرح درخواست"; minLines = 4; gravity = Gravity.TOP; textSize = 15f }
        c.addView(title, paramsTop())
        c.addView(desc, paramsTop())
        addButton(c, "ثبت تیکت") {
            if (title.text.toString().trim().isEmpty()) {
                title.error = "عنوان را وارد کنید"
            } else {
                db.addTicket(title.text.toString().trim(), desc.text.toString().trim())
                Toast.makeText(this, "تیکت در گوشی ذخیره شد", Toast.LENGTH_SHORT).show()
                showDashboard()
            }
        }
        addButton(c, "بازگشت") { showDashboard() }
    }

    private fun showTickets(onlyOpen: Boolean) {
        val c = base("فهرست تیکت‌ها", "ذخیره‌شده روی همین دستگاه")
        val list = if (onlyOpen) db.tickets().filter { it.status == "در انتظار" } else db.tickets()
        if (list.isEmpty()) c.addView(text("تیکتی وجود ندارد.", 15, Color.GRAY).padTop(12))
        list.forEach { c.addView(ticketCard(it) { openTicket(it) }) }
        addButton(c, "بازگشت") { showDashboard() }
    }

    private fun openTicket(t: Ticket) {
        val c = base("جزئیات تیکت", "شماره ${t.id} • ${t.status}")
        c.addView(text(t.title, 20, navy, true))
        c.addView(text(t.description.ifBlank { "بدون توضیحات" }, 15, Color.DKGRAY).padTop(10))
        c.addView(text("ثبت‌کننده: ${t.owner}", 13, Color.GRAY).padTop(10))
        c.addView(text("پاسخ مسئول: ${t.reply.ifBlank { "هنوز پاسخی ثبت نشده" }}", 15, Color.DKGRAY).padTop(12))
        if (role == "staff" || role == "admin") {
            addButton(c, "ثبت پاسخ") {
                val input = EditText(this).apply { hint = "متن پاسخ"; minLines = 3 }
                AlertDialog.Builder(this).setTitle("پاسخ به تیکت")
                    .setView(input).setNegativeButton("انصراف", null)
                    .setPositiveButton("ذخیره") { _, _ ->
                        db.reply(t.id, input.text.toString())
                        openTicket(db.tickets().first { it.id == t.id })
                    }.show()
            }
            addButton(c, "تغییر وضعیت به پاسخ داده شد") {
                db.status(t.id, "پاسخ داده شد")
                openTicket(db.tickets().first { it.id == t.id })
            }
        }
        addButton(c, "بازگشت به تیکت‌ها") { showTickets(false) }
    }

    private fun showUsers() {
        val c = base("مدیریت کاربران", "کاربران نمونه محلی")
        listOf("دانشجو: student", "مسئول: staff", "مدیر: admin").forEach {
            c.addView(text("●  $it", 16, navy).padTop(12))
        }
        addButton(c, "افزودن کاربر آزمایشی") {
            val input = EditText(this).apply { hint = "نام کاربری جدید" }
            AlertDialog.Builder(this).setTitle("کاربر جدید")
                .setView(input).setNegativeButton("انصراف", null)
                .setPositiveButton("افزودن") { _, _ ->
                    val name = input.text.toString().trim()
                    if (name.isNotEmpty()) {
                        Toast.makeText(this, "کاربر $name به فهرست نمایشی اضافه شد", Toast.LENGTH_LONG).show()
                    }
                }.show()
        }
        addButton(c, "بازگشت") { showDashboard() }
    }

    private fun showAnnouncements() {
        val c = base("اطلاعیه‌ها", "اطلاعیه‌های نمونه")
        c.addView(text("۱. سامانه تیکت در حالت آزمایشی فعال است.", 15, navy).padTop(12))
        c.addView(text("۲. اطلاعات این نسخه فقط روی همین گوشی نگهداری می‌شود.", 15, navy).padTop(12))
        c.addView(text("۳. در نسخه عملیاتی، سیاست پشتیبان‌گیری و امنیت اطلاعات باید تعریف شود.", 15, navy).padTop(12))
        addButton(c, "بازگشت") { showDashboard() }
    }

    private fun ticketCard(t: Ticket, click: () -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.WHITE)
            setOnClickListener { click() }
        }
        box.addView(text("#${t.id}  ${t.title}", 16, navy, true))
        box.addView(text("${t.owner}  •  ${t.status}", 13, blue).padTop(6))
        box.addView(text("برای مشاهده جزئیات لمس کنید", 12, Color.GRAY).padTop(4))
        val lp = paramsTop()
        lp.bottomMargin = dp(10)
        box.layoutParams = lp
        return box
    }

    private fun statCard(label: String, value: String): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(8), dp(6), dp(8))
            setBackgroundColor(Color.WHITE)
            addView(text(value, 22, blue, true))
            addView(text(label, 11, Color.DKGRAY))
        }
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = 14f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(blue)
            setOnClickListener { action() }
        }
        val lp = paramsTop()
        lp.bottomMargin = dp(7)
        parent.addView(b, lp)
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.RIGHT
        }

    private fun View.padTop(px: Int): View { setPadding(paddingLeft, dp(px), paddingRight, paddingBottom); return this }
    private fun paramsTop() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}

data class Ticket(val id: Int, val title: String, val description: String, val owner: String, val status: String, val reply: String)

class DemoDb(context: android.content.Context) : android.database.sqlite.SQLiteOpenHelper(context, "uniticket_demo.db", null, 1) {
    override fun onCreate(db: android.database.sqlite.SQLiteDatabase) {
        db.execSQL("CREATE TABLE tickets (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, description TEXT, owner TEXT, status TEXT, reply TEXT)")
        db.execSQL("INSERT INTO tickets(title,description,owner,status,reply) VALUES ('درخواست گواهی اشتغال به تحصیل','برای ارائه به محل کار به گواهی نیاز دارم.','student','در انتظار','')")
        db.execSQL("INSERT INTO tickets(title,description,owner,status,reply) VALUES ('مشکل انتخاب واحد','درس انتخابی در سامانه نمایش داده نمی‌شود.','student','پاسخ داده شد','در حال بررسی توسط آموزش هستیم.')")
        db.execSQL("INSERT INTO tickets(title,description,owner,status,reply) VALUES ('درخواست اصلاح اطلاعات','شماره تماس نیاز به اصلاح دارد.','student','در انتظار','')")
    }
    override fun onUpgrade(db: android.database.sqlite.SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun tickets(): List<Ticket> {
        val out = mutableListOf<Ticket>()
        readableDatabase.rawQuery("SELECT id,title,description,owner,status,reply FROM tickets ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out.add(Ticket(c.getInt(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5)))
        }
        return out
    }
    fun addTicket(title: String, description: String) {
        writableDatabase.execSQL("INSERT INTO tickets(title,description,owner,status,reply) VALUES (?,?,?,'در انتظار','')", arrayOf(title, description, "student"))
    }
    fun reply(id: Int, reply: String) { writableDatabase.execSQL("UPDATE tickets SET reply=? WHERE id=?", arrayOf(reply, id)) }
    fun status(id: Int, status: String) { writableDatabase.execSQL("UPDATE tickets SET status=? WHERE id=?", arrayOf(status, id)) }
}
