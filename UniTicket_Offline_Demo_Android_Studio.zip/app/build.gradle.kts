plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ir.uniticket.offline"
    compileSdk = 35
    defaultConfig {
        applicationId = "ir.uniticket.offline"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0-demo"
    }
}
